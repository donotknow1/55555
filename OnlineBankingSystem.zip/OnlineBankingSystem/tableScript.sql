DROP TABLE user_login;
DROP TABLE admin_login;
DROP TABLE Service_Tracker;
DROP TABLE transaction;
DROP TABLE payee_table;
DROP SEQUENCE accId_seq;
DROP SEQUENCE transId_seq;
DROP SEQUENCE service_seq;

CREATE TABLE user_login(
	username VARCHAR2(25) UNIQUE,
	password VARCHAR2(25),
	Account_ID NUMBER(10) PRIMARY KEY ,
	customer_name VARCHAR2(50),
	Email VARCHAR2(30),
	Address VARCHAR2(100),
	phone_no VARCHAR2(10),
	Pancard VARCHAR2(15),
	Amount NUMBER(10,2)
);


CREATE SEQUENCE accId_seq
START WITH 1000001
NOCACHE;



CREATE TABLE admin_login(
	username VARCHAR2(10) PRIMARY KEY,
	password VARCHAR2(10)
);



INSERT INTO admin_login VALUES('123','123');

CREATE TABLE transaction(
	Transaction_ID NUMBER PRIMARY KEY,
	Tran_description VARCHAR2(100), 
	DateofTransaction DATE , 
	TranAmount NUMBER(15,2) ,
	Account_No NUMBER(10),
	amount NUMBER(10,2)
);


CREATE SEQUENCE transId_seq
START WITH 1001
NOCACHE;

CREATE TABLE Service_Tracker (
	Service_ID NUMBER(10) PRIMARY KEY, 
	Service_Description VARCHAR2(100),
	Account_ID NUMBER UNIQUE, 
	Service_Raised_Date DATE ,
	Service_status VARCHAR2(20)
);


CREATE SEQUENCE service_seq
START WITH 55551
NOCACHE;

CREATE TABLE Payee_Table(
sNo NUMBER PRIMARY KEY,
Account_Id NUMBER  ,
Payee_Account_Id NUMBER, 
Payee_name VARCHAR2(40)
);

commit;

INSERT INTO user_login VALUES('123','123',accId_seq.NEXTVAL,'Krishan','krishankumar96786@gmail.com','whitefield','7662022951','awwwddadada',2500);

INSERT INTO user_login VALUES('1234','1234',accId_seq.NEXTVAL,'Shivam','shivsoni@gmail.com','whitefield','7662022951','awwwddadada',2500);

commit;



--INSERT INTO user_login VALUES('123','123',accId_seq.NEXTVAL,'Krishan','krishankumar96786@gmail.com','whitefield','7662022951','awwwddadada',2500);

/*INSERT INTO transaction VALUES(1,'ADAD','12-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','15-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','17-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','18-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','19-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','20-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','21-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','22-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','23-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','24-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','25-SEP-2017','F',1234,123456789);
INSERT INTO transaction VALUES(1,'ADAD','26-SEP-2017','F',1234,123456789);*/


