package com.cg.bankingapp.service;



import java.util.List;




import com.cg.bankingapp.dto.Admin;
import com.cg.bankingapp.dto.Payee;
import com.cg.bankingapp.dto.ServiceRequest;
import com.cg.bankingapp.dto.Transaction;
import com.cg.bankingapp.dto.User;
import com.cg.bankingapp.exception.BankingException;

public interface IBankingService {

	public User checkUserCredentials(String username,String password) throws BankingException;
	
	public String getChequeBookStatus(int accountNumber) throws BankingException;
	
	public int raiseChequeBookRequest(int accountId,String serviceDescription) throws BankingException;
	
	public List<Transaction> getMiniStatement(int accountId) throws BankingException;
	
	public List<Transaction> getDetailedStatement(String startDate,String endDate,int accountId) throws BankingException;
	
	public User changeUserDetails(String address,String phoneNo,int accountId) throws BankingException;
	
	public boolean changePassword(String password,int accountId) throws BankingException;
	
	public ServiceRequest checkServiceExist(int serviceId) throws BankingException;
	
	public List<Payee> getAllUser(int accountId) throws BankingException;
	
	public boolean fundTransfer(int accno, double amount) throws BankingException;
	
	public boolean fundSub(int accountId, double amount) throws BankingException;
	
	public boolean addPayee(Payee payee) throws BankingException;

	public boolean checkPayee(int paccId,int accId) throws BankingException;
	
	//admin services 
	public boolean checkAdminCredentials(Admin admin) throws BankingException;
	
	public int addUser(User user) throws BankingException;
	
	public List<Transaction> getAllTransactions(String startDate1,String endDate1) throws BankingException;
	
}
