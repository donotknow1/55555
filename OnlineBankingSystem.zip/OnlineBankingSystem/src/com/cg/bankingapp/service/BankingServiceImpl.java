package com.cg.bankingapp.service;

import java.util.List;

import javax.transaction.Transactional;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.bankingapp.dao.IBankingDao;
import com.cg.bankingapp.dto.Admin;
import com.cg.bankingapp.dto.Payee;
import com.cg.bankingapp.dto.ServiceRequest;
import com.cg.bankingapp.dto.Transaction;
import com.cg.bankingapp.dto.User;
import com.cg.bankingapp.exception.BankingException;

@Service
@Transactional
public class BankingServiceImpl implements IBankingService {

	@Autowired
	IBankingDao dao;
	
	
	public IBankingDao getDao() {
		return dao;
	}

	public void setDao(IBankingDao dao) {
		this.dao = dao;
	}

	@Override
	public User checkUserCredentials(String username,String password) throws BankingException {
		
		return dao.checkUserCredentials(username,password);
	}

	@Override
	public boolean checkAdminCredentials(Admin admin) throws BankingException {
		
		return dao.checkAdminCredentials(admin);
	}

	@Override
	public List<Transaction> getMiniStatement(int accountId) throws BankingException {
		
		return dao.getMiniStatement(accountId);
	}

	@Override
	public List<Transaction> getDetailedStatement(String startDate,String endDate,int accountId)
			throws BankingException {
		return dao.getDetailedStatement(startDate,endDate,accountId);
	}

	@Override
	public String getChequeBookStatus(int accountNumber) throws BankingException{
		return dao.getChequeBookStatus(accountNumber);
	}

	@Override
	public int raiseChequeBookRequest(int accountId,String serviceDescription) throws BankingException {
		// TODO Auto-generated method stub
		return dao.raiseChequeBookRequest(accountId,serviceDescription);
	}

	@Override
	public ServiceRequest checkServiceExist(int serviceId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.checkServiceExist(serviceId);
	}
	
	
	@Override
	public User changeUserDetails(String address,String phoneNo,int accountId) throws BankingException {
		
		return dao.changeUserDetails(address, phoneNo,accountId);
	}

	@Override
	public boolean changePassword(String password,int accountId) throws BankingException{
		
		return dao.changePassword(password,accountId);
	}

	@Override
	public boolean fundTransfer(int accno, double amount) throws BankingException {
		// TODO Auto-generated method stub
		return dao.fundTransfer(accno, amount);
	}

	@Override
	public List<Payee> getAllUser(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.getAllUser(accountId);
	}

	
	@Override
	public boolean fundSub(int accountId, double amount) throws BankingException {
		return	dao.fundSub( accountId, amount);
		
	}

	@Override
	public boolean addPayee(Payee payee) throws BankingException {
		// TODO Auto-generated method stub
		return dao.addPayee(payee);
	}

	@Override
	public boolean checkPayee(int paccId,int accId) throws BankingException {
		// TODO Auto-generated method stub
		return dao.checkPayee(paccId,accId);
	}
	
	//admin services
	
	@Override
	public int addUser(User user) throws BankingException {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}

	@Override
	public List<Transaction> getAllTransactions(String startDate1,String endDate1) throws BankingException {
		// TODO Auto-generated method stub
		return dao.getAllTransactions(startDate1, endDate1);
	}


}
