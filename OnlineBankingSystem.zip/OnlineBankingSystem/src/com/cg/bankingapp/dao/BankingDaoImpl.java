package com.cg.bankingapp.dao;


import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bankingapp.dto.Admin;
import com.cg.bankingapp.dto.Payee;
import com.cg.bankingapp.dto.ServiceRequest;
import com.cg.bankingapp.dto.Transaction;
import com.cg.bankingapp.dto.User;
import com.cg.bankingapp.exception.BankingException;


@Repository
public class BankingDaoImpl implements IBankingDao {


	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public User checkUserCredentials(String username,String password) throws BankingException {
		TypedQuery<User>  query = entityManager.createQuery("SELECT u from User u WHERE u.username= :username", User.class);
		query.setParameter("username",username);
		
		List<User> list = query.getResultList();
	
		if(!list.isEmpty() && list.get(0).getPassword().equals(password)){
				return list.get(0);
		}
		return null;
	}

	

	@Override
	public List<Transaction> getMiniStatement(int accountId) throws BankingException {

		System.out.println(accountId);
		
		TypedQuery<Transaction>  query = entityManager.createQuery("Select t from Transaction t WHERE t.accountNumber= :accno order by t.dateOfTransaction desc", Transaction.class);
		query.setParameter("accno",accountId);
		query = query.setMaxResults(10);
		
		return query.getResultList();
	}

	@Override
	public List<Transaction> getDetailedStatement(String startDate,String endDate,int accountId) throws BankingException {
		
		startDate = changeFormat(startDate);
		endDate = changeFormat(endDate);
		
		TypedQuery<Transaction>  query = entityManager.createQuery("SELECT t FROM Transaction t "
				+ "WHERE (t.dateOfTransaction BETWEEN to_date(:start,'dd-MON-yy') AND "
				+ "to_date(:end,'dd-MON-yy')+(1-1/24/60/60)) AND t.accountNumber=:accno ORDER BY t.dateOfTransaction desc", Transaction.class);
		query.setParameter("accno",accountId);
		query.setParameter("start",startDate);
		query.setParameter("end",endDate);
		return query.getResultList();
		
	}

	@Override
	public String getChequeBookStatus(int accountNumber) throws BankingException {

		TypedQuery<ServiceRequest>  query = entityManager.createQuery("SELECT s FROM ServiceRequest s WHERE s.accountId=:accno",ServiceRequest.class);
		query.setParameter("accno", accountNumber);
		ServiceRequest serviceRequest = query.getSingleResult();
		if(serviceRequest!=null)
			return serviceRequest.getServiceStatus();
		else
			return null;
				
	}
	
	@Override
	public int raiseChequeBookRequest(int accountId,String serviceDescription) throws BankingException {
		
		TypedQuery<ServiceRequest>  query = entityManager.createQuery("SELECT s FROM ServiceRequest s WHERE s.accountId=:accno",ServiceRequest.class);
		query.setParameter("accno", accountId);
		ServiceRequest serviceRequest = query.getSingleResult();
		
		serviceRequest.setServiceDescription(serviceDescription);
		serviceRequest.setServiceStatus("dispatched");
		entityManager.merge(serviceRequest);
		
		return serviceRequest.getServiceId();
		
	}

	
	@Override
	public ServiceRequest checkServiceExist(int serviceId) throws BankingException {

		return entityManager.find(ServiceRequest.class, serviceId);
		
		
		
	}
	
	@Override
	public User changeUserDetails(String address,String phoneNo,int accountId) throws BankingException {

		
		User user = entityManager.find(User.class, accountId);
		user.setAddress(address);
		user.setPhoneNo(phoneNo);
		entityManager.merge(user);
		if(entityManager.merge(user)!=null)
		return user;
		else
			return null;
		
	}
	

	@Override
	public boolean changePassword(String password, int accountId) throws BankingException {
		
	
		
		User user = entityManager.find(User.class, accountId);
		if(user!=null && !user.getPassword().equals(password)){
			user.setPassword(password);
			entityManager.merge(user);
			return true;
		}
		return false;
		
		
	}
	public String changeFormat(String date) throws BankingException{

		String finalDate;
		String month[] = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL",
				"AUG", "SEP", "OCT", "NOV", "DEC" };

		String year = date.substring(2, 4);

		int mon = Integer.parseInt(date.substring(5, 7));
		String mm = month[mon - 1];
		String day = date.substring(8, 10);
		finalDate = day + '-' + mm + '-' + year;
		return finalDate;
	}

	public List<Payee> getAllUser(int accountId) throws BankingException{
	
		
		TypedQuery<Payee>  query = entityManager.createQuery("SELECT p FROM Payee p WHERE p.accountId = :accno",Payee.class);
				
				query.setParameter("accno",accountId);
		
		return query.getResultList();
		
	}

	@Override
	public boolean fundTransfer(int accountId, double amount) throws BankingException {
		
		
		User user = entityManager.find(User.class, accountId);
		if(user!=null){
			user.setAmount(user.getAmount()+amount);
	
			double availBalance = user.getAmount();
			
			Date date = new Date();
			Transaction transaction = new Transaction();
			transaction.setAccountNumber(accountId);
			transaction.setDateOfTransaction(date);
			transaction.setAmount(availBalance);
			transaction.setTransactionAmount(amount);
			transaction.setTransactionDescription("Credit");
			
			entityManager.persist(transaction);
			entityManager.flush();
			return true;
		}
		return false;
		
	}

	@Override
	public boolean fundSub(int accountId, double amount) throws BankingException {
	
		
		User user = entityManager.find(User.class, accountId);
		
		if(user!=null){
			user.setAmount(user.getAmount()-amount);
			double availBalance = user.getAmount();
			if(availBalance<amount)
				return false;
			else{
				
				Date date = new Date();
				Transaction transaction = new Transaction();
				transaction.setAccountNumber(accountId);
				transaction.setDateOfTransaction(date);
				transaction.setAmount(availBalance);
				transaction.setTransactionAmount(amount);
				transaction.setTransactionDescription("Debit");
				
				entityManager.persist(transaction);
				entityManager.flush();
				return true;
			}
		}
		return false;
		}

	@Override
	public boolean addPayee(Payee payee) throws BankingException {

		
		
		
		entityManager.persist(payee);
		entityManager.flush();
		return true;
		
	}

	@Override
	public boolean checkPayee(int paccId,int accId) throws BankingException {
	
		User user = entityManager.find(User.class, paccId);
		if(user!=null){
		TypedQuery<Payee>  query = entityManager.createQuery("SELECT p FROM Payee p WHERE p.accountId = :accno AND p.payeeAccountId=:payeeno",Payee.class);
		
		query.setParameter("accno",accId);
		query.setParameter("payeeno",paccId);
		
		List<Payee> list = query.getResultList();
			if(list.isEmpty()){
				return true;
			}
		}
		return false;
		
		
	}
	/*************************************
			admin dao implementation
	*****************************************/
	@Override
	public boolean checkAdminCredentials(Admin admin) throws BankingException {


		Admin admin1 = entityManager.find(Admin.class, admin.getUsername());
		if(admin1!=null && admin1.getPassword().equals(admin.getPassword())){
			return true;
	}
	return false;
		
	}
	
	@Override
	public int addUser(User user) throws BankingException {
		
		TypedQuery<User>  query = entityManager.createQuery("SELECT u FROM User u WHERE u.username = :username",User.class);
		
		query.setParameter("username",user.getUsername());
		List<User> list = query.getResultList();
		
		if(list.isEmpty()){
			entityManager.persist(user);
			entityManager.flush();

			Date date = new Date();
			Transaction transaction = new Transaction();
			transaction.setAccountNumber(user.getAccountId());
			transaction.setAmount(user.getAmount());
			transaction.setDateOfTransaction(date);
			transaction.setTransactionAmount(user.getAmount());
			transaction.setTransactionDescription("Credit");
			entityManager.persist(transaction);
			entityManager.flush();
			ServiceRequest serv = new ServiceRequest();
			serv.setServiceDescription("newly created account");
			serv.setAccountId(user.getAccountId());
			serv.setServiceRaisedDate(date);
			serv.setServiceStatus("not issued");
			entityManager.persist(serv);
			entityManager.flush();

			return user.getAccountId();
		}
		else
		{
			return 0;
		}
	}

	@Override
	public List<Transaction> getAllTransactions(String startDate1,String endDate1) throws BankingException {
		
		startDate1 = changeFormat(startDate1);
		endDate1 = changeFormat(endDate1);
		TypedQuery<Transaction>  query = entityManager.createQuery("SELECT t FROM Transaction t "
				+ "WHERE (t.dateOfTransaction BETWEEN to_date(:start,'dd-MON-yy') AND "
				+ "to_date(:end,'dd-MON-yy')+(1-1/24/60/60)) ORDER BY t.accountNumber", Transaction.class);
		query.setParameter("start",startDate1);
		query.setParameter("end",endDate1);
		return query.getResultList();
	
	}
}
