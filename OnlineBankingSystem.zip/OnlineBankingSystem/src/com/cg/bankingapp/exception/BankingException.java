package com.cg.bankingapp.exception;

public class BankingException extends Exception {

	private static final long serialVersionUID = 1L;

	public BankingException(String str2) {
		super(str2);
	}
	
}
